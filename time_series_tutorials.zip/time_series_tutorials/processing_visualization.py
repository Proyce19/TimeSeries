import pandas as pd
import datetime
from sklearn import metrics
from math import sqrt
from matplotlib import pyplot as plt
import numpy as np
df = pd.read_csv('AirQualityUCI/AirQualityUCI.csv',sep=";",decimal=",")
#print(len(df))
df=df.iloc[:,0:14]
#print(df.isna().sum())
df = df[df['Date'].notnull()]
df['DateTime']=(df.Date)+' '+(df.Time)
#print(df.DateTime[0])

df.DateTime = df.DateTime.apply(lambda x: datetime.datetime.strptime(x,'%d/%m/%Y %H.%M.%S'))
#print(df.DateTime[0])
df.index = df.DateTime
#print("Mean: ",np.mean(df['T']),"\nStandard Deviation: ",np.std(df['T']),"\nMaximum Temperature: ",np.max(df['T']),
 #     "\nMinimum Temperature: ",np.min(df['T']))

df['T_t-1'] =df['T'].shift(1)
df['T_rm']=df['T'].rolling(3).mean().shift(1)
df_naive = df[['T','T_t-1']][1:]
df_naive1 = df[['T','T_rm']].dropna()
true = df_naive['T']
prediction = df_naive['T_t-1']
prediction1 = df_naive1['T_rm']
error = sqrt(metrics.mean_squared_error(true,prediction))

plt.plot(true[:10])

plt.plot(prediction[:10],color='red')
plt.plot(prediction1[:10],color='green')
plt.show()

print('RMSE for Naive Method 1:',error)



