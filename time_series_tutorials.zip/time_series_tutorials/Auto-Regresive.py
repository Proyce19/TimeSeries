import pandas as pd
import datetime
from sklearn import metrics
from math import sqrt
from matplotlib import pyplot as plt
import numpy as np
df = pd.read_csv('AirQualityUCI/AirQualityUCI.csv',sep=";",decimal=",")
#print(len(df))
df=df.iloc[:,0:14]
#print(df.isna().sum())
df = df[df['Date'].notnull()]
df['DateTime']=(df.Date)+' '+(df.Time)
#print(df.DateTime[0])

df.DateTime = df.DateTime.apply(lambda x: datetime.datetime.strptime(x,'%d/%m/%Y %H.%M.%S'))
#print(df.DateTime[0])
df.index = df.DateTime

from statsmodels.graphics.tsaplots import plot_acf
split = len(df) - int(0.2*len(df))
train,test = df['T'][0:split],df['T'][split:]
plot_acf(train,lags=100)
plot_acf(test,lags=100)
plt.show()